import c4d
from c4d import gui
from c4d import utils

def state():
    doc = c4d.documents.GetActiveDocument()
    selObjs = doc.GetActiveObjects(0)
    if len(selObjs)==0:
        return False
    return True

#apply hierarchycal scaling to the mesh and offset relative position accordingly
def freezeGlobalScale(obj):
    #print(obj.GetName())

    doc = c4d.documents.GetActiveDocument()

    worldMat = obj.GetMg()
    globalPos = worldMat.off
    globalRot = utils.MatrixToHPB(worldMat)
                        
    parentWorldMat = c4d.Matrix()
    parentScaleMat = c4d.Matrix()

    parent = obj.GetUp()
    if parent is not None:
        parentWorldMat = parent.GetMg()
        pScale = c4d.Vector(parentWorldMat.v1.GetLength(),
                            parentWorldMat.v2.GetLength(),
                            parentWorldMat.v3.GetLength())
        parentScaleMat = c4d.utils.MatrixScale(pScale)
        

    globalPosRot = utils.HPBToMatrix(globalRot, c4d.ROTATIONORDER_HPB)  
    globalPosRot.off = globalPos
    xform = ~globalPosRot * worldMat

    deltaPos = obj.GetRelPos()* parentScaleMat
    
    doc.AddUndo(c4d.UNDOTYPE_CHANGE, obj)

    if type(obj) is c4d.PolygonObject:
        points = obj.GetAllPoints()
        for i in xrange(len(points)):
            points[i] = points[i] * xform

        obj.SetAllPoints(points)

    obj.SetRelScale( c4d.Vector(1,1,1))
    obj.SetRelPos( deltaPos )

    obj.Message(c4d.MSG_UPDATE)

def recursiveFreezeScale( root, startObj ):
    if root is None:
        return

    firstChild = root.GetDown()
    recursiveFreezeScale(firstChild, startObj)

    freezeGlobalScale(root)

    if root is startObj:
        return

    nextSibling = root.GetNext()
    recursiveFreezeScale(nextSibling, startObj)


# Main function
def main():
    doc = c4d.documents.GetActiveDocument()
    selObjs = doc.GetActiveObjects(0) #get list of selected objects
    if len(selObjs)==0:
        return

    doc.StartUndo()

    for o in selObjs:
        if o.GetUp() not in selObjs:
            recursiveFreezeScale(o, o)

    doc.EndUndo()

    c4d.EventAdd()

# Execute main()
if __name__=='__main__':
    main()