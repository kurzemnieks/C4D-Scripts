import c4d
from c4d import gui
import keyVisAnim

def state():
    doc = c4d.documents.GetActiveDocument()
    selObjs = doc.GetActiveObjects(0)
    if len(selObjs)==0:
        return False
    return True

# Main function
def main():
    
    doc = c4d.documents.GetActiveDocument()
    selObjs = doc.GetActiveObjects(0) #get list of selected objects
    if len(selObjs)==0:
        return

    doc.StartUndo()

    visEID = c4d.DescID(c4d.ID_BASEOBJECT_VISIBILITY_EDITOR)
    visRID = c4d.DescID(c4d.ID_BASEOBJECT_VISIBILITY_RENDER)
    
    for obj in selObjs:
        ao = keyVisAnim.GetAnimObj(obj, visEID)
        keyVisAnim.AddVisibilityKeyframe( ao, visEID, 0)
        ao = keyVisAnim.GetAnimObj(obj, visRID)
        keyVisAnim.AddVisibilityKeyframe( ao, visRID, 0)
        doc.AddUndo(c4d.UNDOTYPE_CHANGE_SMALL, ao)

    doc.EndUndo()
    c4d.EventAdd()
    c4d.DrawViews(c4d.DRAWFLAGS_FORCEFULLREDRAW)


# Execute main()
if __name__=='__main__':
    main()