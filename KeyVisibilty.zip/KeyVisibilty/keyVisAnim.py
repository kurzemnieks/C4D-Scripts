import c4d
from c4d import gui
from pprint import pprint


def GetAnimObj(obj, descID):
    doc = c4d.documents.GetActiveDocument()
    takeData = doc.GetTakeData()
    if takeData is None:
        return obj

    take = takeData.GetCurrentTake()
    if take.IsMain():
        return obj

    if not takeData.CheckOverrideEnabling(c4d.OVERRIDEENABLING_ENABLING): #Take override mode disabled
        return obj
        
    override = take.FindOrAddOverrideParam( takeData, obj, descID, 1 )

    return override

def AddVisibilityKeyframe( obj, descID, value ):
    if type(obj) is c4d.modules.takesystem.BaseOverride:
        bobj = obj.GetSceneNode()
    else:
        bobj = obj
       
    track = bobj.FindCTrack( descID )
    if track is None:
        track = c4d.CTrack( bobj, descID )
        bobj.InsertTrackSorted( track )


    doc = c4d.documents.GetActiveDocument()
    t = doc.GetTime()
    crv = track.GetCurve()
    key = crv.AddKey(t,bUndo=True)['key']
    key.SetGeData(crv, value)
    return




