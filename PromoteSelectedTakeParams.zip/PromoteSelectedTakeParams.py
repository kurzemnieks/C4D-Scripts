# Promote selected take overriden parameters
# Usage: 
# 1. Select take you want to promote parameters from
# 2. Select Objects in take parameters window whose overrides you want to promote
# 3. Call the PromoteSelectedTakeParams command 

import c4d
from c4d import gui

def state():
    return True
    #Currently this does not work properly because state check is called only when clicking in other
    #UI part than Takes Window. Therefore it does not update correctly when clicking changing take 
    #override selection
    
    doc = c4d.documents.GetActiveDocument()
    takeData = doc.GetTakeData()
    if takeData is None:
        return False
    selTakes = takeData.GetTakeSelection(children=False)
    for t in selTakes:
        if not t.IsMain():
            takeParamsList = t.GetOverrides()
            for o in takeParamsList:
                if o.GetBit(c4d.BIT_ACTIVE):
                    return True
    return False


def PromoteTakeParamsToParent( takeData, take ):

    if take is None:
        return
    if take.IsMain():
        return

    parentTake = take.GetUp()

    takeParamsList = take.GetOverrides()
    for o in takeParamsList:
        overrideDescIDs = o.GetAllOverrideDescID()

        if o.GetBit(c4d.BIT_ACTIVE):
            for oid in overrideDescIDs:
                ovalue = o.GetParameter( id=oid, flags=c4d.DESCFLAGS_GET_NONE )

                track = o.FindCTrack(oid)

                node = o.GetSceneNode()
                take.DeleteOverride( takeData, node, oid )

                op = parentTake.FindOrAddOverrideParam(takeData, node, oid, ovalue)

                parentTrack = op.FindCTrack(oid)
                if parentTrack is not None:
                    parentTrack.Remove()

                if parentTake.IsMain():
                    parentTrack = node.FindCTrack(oid)
                    if parentTrack is not None:
                        parentTrack.Remove()

                if track is not None:

                    if parentTake.IsMain():
                        node.InsertTrackSorted(track)
                        #print("inserted track to object" + str(track))
                    else:
                        op.InsertTrackSorted(track)
                        op.UpdateSceneNode(takeData,oid)

                else:
                    op.SetParameter( oid, ovalue, c4d.DESCFLAGS_SET_NONE)
                    op.UpdateSceneNode(takeData,oid)

# Main function
def main():
    doc = c4d.documents.GetActiveDocument()
    doc.StartUndo()
    takeData = doc.GetTakeData()
    if takeData is None:
        return

    takeCurrent = takeData.GetCurrentTake()
    selectedTakesList = takeData.GetTakeSelection(children=False)

    for t in selectedTakesList:
        PromoteTakeParamsToParent( takeData, t )

    doc.EndUndo()
    c4d.EventAdd()
    c4d.DrawViews(c4d.DRAWFLAGS_FORCEFULLREDRAW)



# Execute main()
if __name__=='__main__':
    main()